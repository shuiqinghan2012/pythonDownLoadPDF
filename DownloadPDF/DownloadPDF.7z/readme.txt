查找BOM中的物料规格书，要一个一个从网站上查找，非常费时间
萌生了写一个程序从Excel BOM中固定位置一个一个取值然后从固定的网站上查找资料
如完全匹配将对应的PDF下载并以Excel值的名称保存

查找资料
1.以访问当PDF后，浏览器会打开PDF，此时只要以二进制的方式保存成.pdf 即可，如下的列子测试ok
https://www.bilibili.com/read/cv10914159/

2.访问datasheet5并从特定器件获取到pdf链接 ok
3. 以1的方式保存，结果访问一直报error
requests.exceptions.ConnectionError: ('Connection aborted.', ConnectionResetError(10054, 'An existing connection was forcibly closed by the remote host', None, 10054, None))

换其它网站试试:https://www.mouser.cn/ PDF页面测试ok
但是前一页面一直403 错误
https://www.mouser.cn/ProductDetail/Texas-Instruments/TUSB1002RGER?qs=zEmsApcVOkXKUslZUCtTrg%3D%3D
403 Client Error: Forbidden for url: https://www.mouser.cn/ProductDetail/Bel-Power-Solutions/DP1501-9RG?qs=DBKgNs46bfQx2Oy1uA5dyQ%3D%3D
403 错误如何解决???

重新设计爬取路径并手动测试
爬取路径：
主页：访问测试ok
www.datasheet5.com
提交搜索的链接后，访问ok----到这一步只需要文本处理，简单
https://www.datasheet5.com/search/TUSB1310ZAY
型号点击后页面访问ok----到这一步，需要解析
    //td[@class="td-part"]/a 返回搜索相近值的列表
    //td[@class="td-part"]/a/@href 对应的url 列表
'https://www.datasheet5.com/part/TUSB1310ZAY/Texas%20Instruments' #ok
    //div[@class="name"]/a/text() 下载pdf的文字部分
    //div[@class="name"]/a/@href 进入pdf页面的链接


网页打开的pdf,测试访问ok，此部分已经链接到了别的网站
https://www.ti.com/lit/ds/symlink/tusb1310.pdf?HQS=ti-null-null-sf-df-pf-sep-wwe&ts=1674025949225&ref_url=https%253A%252F%252Fwww.datasheet5.com%252F
有部分网站能爬到pdf页面，但下载不成功

从主页到搜索页面实现？文本实现 ok


0119:全链路打通，但没有处理特殊情况，计划：特殊情况直接返回，然后在对应的Excel中填写连接或者找不到字样
['ASP-134486-01', 878321420, 'HR911130A', 2086581051, '502570-0893', '20525-030E-02', 39296088, 39296068, 'ASP-184329_01', '20525-050E-02', 'CL05A106MQ5NUNC', 'GRM155R71E104KE14D', 'CL05A475KP5NRNC', 'CL10C101JB8NNNC', 'CC0402JRNPO7BN391', 'GRM155R71E104KE14D', 'CL05A105KP5NNNC', 'CL05B102KB5NNNC', 'CL05B103KB5NNNC', '0402B561K500NT', 'CC0402KRX7R8BB683', 'GRM155R61E474KE01D', 'GCM1555C1H3R3BA16D', 'CL21A226MAYNNNE', 'CL31A476MPHNNNE', 'EEFSX0E331XE', 'GRM21BR60J107ME15L', 'GJM1555C1H330GB01D', 'GRM155R61E225KE11D', '10SVPC120MV', 'GCM155R71H332JA37D', 'CC0402KRX5R8BB224', 'GRM1555C1H120JA01D', 'EEHZK1E471P', '4TPE220MAZB', 'CL10A475KA8NQNC', 'EEFSX0D471E4', 'CL10B223KB8NNNC', 'TPD4E02B04DQAR', 'SP3003-04JTG', 'TPD1E05U06DPYR', 'TPD4E05U06DQAR', 'SESD0402X1UN-0020-090', 'SMAJ12A-TR', 'BLM18PG181SN1D', 'BLM18PG121SN1D', 'BLM21PG600SN1D', 'BLM15PX600SN1D', 'BLM18EG221SN1D', 1054500101, 'AXE530127D', 475890001, '#N/A', 'AWHW20G-0202-T-R', 'PPPC062LJBN-RC', '11500W90-4P-S-W3', 'FH12-22S-1SH(55)', '#N/A', 'SML-D12M8WT86', 'WPN252012H2R2MTY01', 'DLW21SN900SQ2L', 'LQW15AN20NJ8ZD', '#N/A', 'AONR21357', 'AO3402', '2N7002DW-7-F', 'RUM001L02T2CL', '2N7002,215', 'DMN62D0UDW-7', 'SI7157DP-T1-GE3', 'RK73B1ETTP205J', 'RC0402JR-070RL', 'RC0402FR-071KL', 'RC0805FR-071ML', 'RC0402FR-071KL', 'RC0402FR-07100KL', 'RC0402FR-0710KL', 'RC0402FR-073K3L', 'RC0402JR-070RL', 'RC0402FR-072K2L', 'SR0805JR-47300RL', 'RC0402FR-0722KL', 'RC0402FR-0710KL', 'RC0402FR-07200KL', 'RC0402FR-074K7L', 'RC0402FR-074K7L', 'RC0402FR-071K87L', 'RC0402FR-074K99L', 'RC0402FR-073K57L', 'RC0402FR-072K87L', 'RC0402FR-071K43L', 'RC0402FR-07240RL', 'RC0402FR-0740R2L', 'ERJ2RKF36R0X', 'RC0402FR-0749R9L', 'RC0402FR-07100RL', 'RC0402FR-0710KL', 'RC0402FR-0722RL', 'RC0402FR-07470RL', 'RC0402FR-071K5L', 'RC0402FR-0733RL', 'RC0402FR-072K49L', 'RC0402FR-078K06L', 'RC0402FR-0722K1L', 'RC0402FR-0747K5L', 'RC0402FR-07470KL', 'RC0402FR-076K81L', 'RC0402FR-0761K9L', 'RC0402FR-0740K2L', 'AC0402FR-073K32L', 'RC0402FR-0761K9L', 'RC0402FR-07499RL', 'RC0402FR-071K6L', 'RC0402FR-073K01L', 'RC0402FR-072K21L', 'RC0402FR-07499RL', 'RC0402FR-0712KL', 'RC0402FR-0751RL', 'RC0402FR-072KL', 'RC0402FR-07143KL', 'RC0402FR-07121KL', 'RC0402FR-0763K3L', 'RC0402FR-075K1L', 'RC0402FR-07147KL', 'RC0402FR-07634RL', 'RC0402FR-075K9L', 'RC0402FR-0720KL', 'RC0402FR-071K96L', 'RC0402FR-0718KL', 'RC0402FR-071K2L', 'RC0402FR-07100KL', 'RC0402FR-07660RL', 'RC0402FR-0749K9L', 'DSHP04TSGER', 'SKQYAAE010', '1101M2S3AQE2', 'RCUCTE', 'TUSB1064IRNQT', 'TUSB1046-DCIRNQT', 'CYPD4226-40LQXIT', 'APL3510EBI-TRG', 'LSF0108PWR', 'TPS74801DRCT', 'MT40A1G16RC-062E', 'XCVU13P-2FHGB2104I', 'MT25QU01GBBB8ESF-0SIT', 'MT40A512M16LY-075:E', 'RTL8211F-CG', 'USB3320C-EZK', 'AP22814AW5-7', 'SGM8000C-S03BBG', 'SP0503BAHTG', 'CP2102N-A02-GQFN24R', 'TMDS181IRGZT', 'TCA9406DCUR', 'XCZU19EG-2FFVC1760I', 'TPS3808G01DBVR', 'TXS02612RTWR', 'ECLAMP2410P.TCT', 'MT25QL01GBBB8ESF-0SIT', 'SN74AVC2T245RSWR', 'SN65MLVD200AD', 'PCA9306DC1,125', 'SN74AVC4T245DGVR', 'CDCLVD1208RHDT', 'SN74LVC3G17DCTR', '8T49N287A-998NLGI', 'LTM4630IY#PBF', 'MYMGK1R820ERSR', 'MUN12AD06-SM', 'MYSGK4R030ERSR', 'TPS7A9001DSKR', 'TPS51206DSQT', 'LTM4650IY#PBF', 'TPS7A8400RGRT', 'SN65DP159RGZT', 'SN75DP130SSRGZR', 'TCA9548ARGER', 'HD3SS2522RHUR', 'TPS2046BD', 'TPS2590RSAR', 'CO75D6-100.000-33JDTSNL', 'NX3225GA-25MHZ-STD-CRA-1', 'SX5M26.000M20F30TNN', 'SG-8018CE 33.333000MHz TJHPA', 'ABM8W-40.0000MHZ-4-B1U-T3', '1.25-2PWB', 'TUSB1002RGER', 'BLM15PX600SN1D', 'RC0402FR-071ML']
https://www.datasheet5.com/search/ASP-134486-01
https://www.datasheet5.com/part/ASP-134486-01/Samtec%20Inc
https://4donline.ihs.com/images/VipMasterIC/IC/SAMI/SAMI-S-A0001055063/SAMI-S-A0000232204-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
下载pdfUrl Failhttps://4donline.ihs.com/images/VipMasterIC/IC/SAMI/SAMI-S-A0001055063/SAMI-S-A0000232204-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
https://www.datasheet5.com/search/878321420
https://www.datasheet5.com/part/87832-1420/Molex
https://4donline.ihs.com/images/VipMasterIC/IC/MOLE/MOLE-S-A0003535444/MOLE-S-A0003535158-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
下载pdfUrl Failhttps://4donline.ihs.com/images/VipMasterIC/IC/MOLE/MOLE-S-A0003535444/MOLE-S-A0003535158-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
https://www.datasheet5.com/search/HR911130A
https://www.datasheet5.com/part/HR911105A/Hanrun%20Electronics%20Co%20Ltd
https://4donline.ihs.com/images/VipMasterIC/IC/HNRN/HNRN-S-A0008492626/HNRN-S-A0008492626-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
下载pdfUrl Failhttps://4donline.ihs.com/images/VipMasterIC/IC/HNRN/HNRN-S-A0008492626/HNRN-S-A0008492626-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
https://www.datasheet5.com/search/2086581051
Traceback (most recent call last):
  File "D:\Work\Study\Python\DownloadPDF\downloadpdf.py", line 21, in <module>
    pdfObj.runDownLoadPDF(str(part))
  File "D:\Work\Study\Python\DownloadPDF\webRequest.py", line 137, in runDownLoadPDF
    self.url = self.getDatasheet5PartUrl()
  File "D:\Work\Study\Python\DownloadPDF\webRequest.py", line 106, in getDatasheet5PartUrl
    url_new = e.xpath('//td[@class="td-part"]/a/@href')[0]
IndexError: list index out of range

Process finished with exit code 1


先封装函数
1.封装log模块  mylog.py
    封装成了类，打印log前面有空格，暂时不调查

2.request HTML 封装类 webRwquest.py
    封装很多单独的函数功能
    部分测试ok

3.封装访问Excel的模块 FileExcel.py
    封装Excel转list
    封装list找partPn，返回partList

4.主调用模块
#downloadpdf.py 为主调用函数
    分别调用如上封装好的模块，并实现下载pdf 的功能






