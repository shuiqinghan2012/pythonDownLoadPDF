# This is a sample Python script.

"""
此段代码测试从浏览器打开的pdf下载到本地，
测试可以保持到本地，名称自定义为name的值
"""
# import time
# import requests
# name = "test"
# url = "http://static.cninfo.com.cn/finalpage/2021-04-17/1209711009.PDF"
# responsepdf = requests.get(url)
# if responsepdf.status_code == 200:
#   with open(r"%s.pdf" %name, "wb") as code:
#     code.write(responsepdf.content)
#     time.sleep(5)  # 防止访问速度过快，可以灵活的调整时间 作者：silencedream https://www.bilibili.com/read/cv10914159/ 出处：bilibili

"""
测试如何从下载页面找到在线打开pdf的网页并保存
"""

# /html/body/div[4]/div/div[3]/div[1]/div[2]/a
import time
import requests
from lxml import etree

name = "testpdf"
url = "https://www.datasheet5.com/part/DP1501-9RG/Bel%20Fuse"

# responsepdf = requests.get(url)
# time.sleep(5)
# if responsepdf.status_code == 200:
#   e = etree.HTML(responsepdf.text)
#   url = e.xpath('//div[@class="file-v first"]/a/@href')
#   url = "".join(url)#这里已经爬到了下载页面的url
#   print(url)
#起始url
# "https://www.datasheet5.com/part/DP1501-9RG/Bel%20Fuse"
# url='https://4donline.ihs.com/images/VipMasterIC/IC/BELF/BELF-S-A0014526752/BELF-S-A0014526752-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0'
# url = 'https://www.mouser.cn/datasheet/2/643/ds_bps_p_series-1314646.pdf'
# # headers
# headers = {
#   "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36"
# }
# responsepdf = requests.get(url, headers=headers)
# print(responsepdf)
# if responsepdf.status_code == 200:
#   with open(r"%s.pdf" %name, "wb") as code:
#     code.write(responsepdf.content)
#     time.sleep(5)
# https://4donline.ihs.com/images/VipMasterIC/IC/BELF/BELF-S-A0014526752/BELF-S-A0014526752-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0


# 爬取网页的通用代码框架
def getHTMLText(url):
  try:
    r = requests.get(url, timeout=3)
    r.raise_for_status()  # 如果状态不是200，引发HTTPError异常
    r.encoding = r.apparent_encoding
    r.a
    return r.text
  except Exception as err:
    print(err)
    return "产生异常"


if __name__ == "__main__":
  # url = "http://www.baidu.com"
  # url='https://4donline.ihs.com/images/VipMasterIC/IC/BELF/BELF-S-A0014526752/BELF-S-A0014526752-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0'
  # url = 'https://www.mouser.cn/ProductDetail/Texas-Instruments/TUSB1002RGER?qs=zEmsApcVOkXKUslZUCtTrg%3D%3D'
  #403错误，不能访问 HTTPSConnectionPool(host='www.mouser.cn', port=443): Read timed out. (read timeout=3)
  # url = 'https://www.mouser.cn/'
  #digikey主页可访问
  # url = 'https://www.digikey.cn/'
  # url = 'HTTPS://www.digikey.cn/zh/products/detail/texas-instruments/SN75DP130SSRGZR/2696369?WT.z_header=search_go&s=N4IgTCBcDaIMoDkDsBWAIgBQIwGYAMccASgOIBaRIAugL5A'
  # url = 'https://www.datasheet5.com/' #ok
  # url = 'https://www.datasheet5.com/search/TUSB1310ZAY' #ok
  # url = 'https://www.datasheet5.com/part/TUSB1310ZAY/Texas%20Instruments' #ok
  # url = 'https://www.ti.com/lit/ds/symlink/tusb1310.pdf?HQS=ti-null-null-sf-df-pf-sep-wwe&ts=1674025694186&ref_url=https%253A%252F%252Fwww.datasheet5.com%252F'
  url = 'https://4donline.ihs.com/images/VipMasterIC/IC/MURE/MURE-S-A0015852517/MURE-S-A0015852387-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0'
  print(getHTMLText(url))
# 当.py文件被直接运行时，if __name__ == '__main__'之下的代码块将被运行；
# 当.py文件以模块形式被导入时，if __name__ == '__main__'之下的代码块不被运行。
# ————————————————
# 版权声明：本文为CSDN博主「hyhpyx」的原创文章，遵循CC
# 4.0
# BY - SA版权协议，转载请附上原文出处链接及本声明。
# 原文链接：https: // blog.csdn.net / hyhpyx / article / details / 106443537


