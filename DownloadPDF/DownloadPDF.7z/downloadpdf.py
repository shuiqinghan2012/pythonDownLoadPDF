#downloadpdf.py 为主调用函数
from mylog import Mylog,logging
from FileExcel import FileExcel
from webRequest import WebRequest


def runMain():

    BomExcelObj = FileExcel(excelPath)
    listT = BomExcelObj.readExcelToList()
    for i in listT:
        print(i)
    print(listT[0])
    partList = BomExcelObj.getColWord()
    print(partList)
    pdfObj = WebRequest()
    # for part in partList:
    for rowNum in range(len(partList)):
        part = partList[rowNum]
        # print(part,rowNum)
        pdfUrlRow = 1+1+ rowNum  # i为partList的位置,list从0开始计数，Excel从1开始，且第一行为标题，所以Excel和list差2行
        # print(pdfUrlRow)
        pdfUrlCol = BomExcelObj.maxCol + 1
        # print(pdfUrlRow, pdfUrlCol)
        try:
            logging.info("下载{}，所在位置为{}，总数为{}".format(part,rowNum,len(partList)))
            print("下载{}，所在位置为{}，总数为{}".format(part,rowNum,len(partList)))
            pdfUrl,state = pdfObj.runDownLoadPDF(str(part))
        except Exception as err:
            logging.debug(err)

        else:#将PDF url和下载ok/NG标准加入到Excel表中
            if state:
                BomExcelObj.writeExcelCell(pdfUrl,pdfUrlRow,pdfUrlCol)
                BomExcelObj.writeExcelCell("OK", pdfUrlRow, pdfUrlCol+1)
            else:
                BomExcelObj.writeExcelCell(pdfUrl, pdfUrlRow, pdfUrlCol)
                BomExcelObj.writeExcelCell("NG", pdfUrlRow, pdfUrlCol+1)
            # print("pdfUrl执行写入Excel")
    #保存Excel
    BomExcelObj.saveResult()



log = Mylog()
log.configLog()

logging.info("开始主程序")
excelPath = 'd:\Work\Study\Python\DownloadPDF\Test_BOM.xlsx'

runMain()